import { useState } from "react";
import { mockRFQs, mockQuotations, statusLabels, statusColors } from "@/data/mock";
import { Clock, Filter, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { RFQItem } from "@/data/mock";

export default function Quotations() {
  const [statusFilter, setStatusFilter] = useState<RFQItem["status"] | "all">("all");
  const [search, setSearch] = useState("");

  const filtered = mockRFQs.filter((rfq) => {
    if (statusFilter !== "all" && rfq.status !== statusFilter) return false;
    if (search && !rfq.title.toLowerCase().includes(search.toLowerCase()) && !rfq.code.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const statuses: Array<RFQItem["status"] | "all"> = ["all", "draft", "sent", "quoting", "ai_analysis", "closed", "cancelled"];
  const statusAllLabels: Record<string, string> = { all: "Todas", ...statusLabels };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Minhas Cotações</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Gerencie todas as suas requisições de cotação
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex items-center gap-2 bg-secondary/50 rounded-lg px-3 py-1.5 flex-1">
          <Search className="h-3.5 w-3.5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar por código ou produto..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none w-full"
          />
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {statuses.map((s) => (
            <Button
              key={s}
              variant={statusFilter === s ? "default" : "ghost"}
              size="sm"
              onClick={() => setStatusFilter(s)}
              className={`text-[10px] font-semibold whitespace-nowrap ${
                statusFilter === s ? "" : "text-muted-foreground"
              }`}
            >
              {statusAllLabels[s]}
            </Button>
          ))}
        </div>
      </div>

      {/* RFQ Cards */}
      <div className="space-y-3">
        {filtered.map((rfq) => {
          const quotes = mockQuotations.filter((q) => q.rfqCode === rfq.code);
          return (
            <div key={rfq.id} className="glass-card rounded-xl p-5 hover:border-primary/20 transition-all">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-primary">{rfq.code}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColors[rfq.status]}`}>
                      {statusLabels[rfq.status]}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-foreground truncate">{rfq.title}</h3>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="text-[10px] text-muted-foreground">
                      Qtd: {rfq.quantity.toLocaleString()} un
                    </span>
                    <span className="text-[10px] text-muted-foreground">
                      {rfq.quotesReceived}/{rfq.suppliersCount} cotações
                    </span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {rfq.deadline}
                    </span>
                  </div>
                </div>

                {/* Mini quote list */}
                {quotes.length > 0 && (
                  <div className="hidden lg:flex flex-col gap-1">
                    {quotes.slice(0, 2).map((q) => (
                      <div key={q.id} className="flex items-center gap-2 text-[10px]">
                        <span>{q.supplierFlag}</span>
                        <span className="text-muted-foreground">${q.unitPrice.toFixed(2)}</span>
                        {q.score && (
                          <span className={`font-bold ${q.score >= 90 ? "text-success" : q.score >= 80 ? "text-primary" : "text-warning"}`}>
                            {q.score}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <p className="text-sm text-muted-foreground">Nenhuma RFQ encontrada</p>
          </div>
        )}
      </div>
    </div>
  );
}
