import { mockSuppliers } from "@/data/mock";
import { Star, Mail, Globe } from "lucide-react";

export default function Suppliers() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Fornecedores</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Base de fornecedores internacionais cadastrados
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockSuppliers.map((supplier) => (
          <div key={supplier.id} className="glass-card rounded-xl p-5 hover:border-primary/20 transition-all">
            <div className="flex items-start gap-3 mb-4">
              <span className="text-2xl">{supplier.flag}</span>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-foreground truncate">
                  {supplier.name}
                </h3>
                <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Globe className="h-3 w-3" /> {supplier.country}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1">
                <Star className="h-3.5 w-3.5 text-primary fill-primary" />
                <span className="text-xs font-bold text-foreground">{supplier.rating}</span>
              </div>
              <span className="text-[10px] text-muted-foreground">
                {supplier.totalQuotes} cotações
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
              <Mail className="h-3 w-3" />
              <span className="truncate">{supplier.email}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
