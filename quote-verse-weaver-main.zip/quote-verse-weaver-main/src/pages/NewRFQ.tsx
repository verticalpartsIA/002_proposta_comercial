import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { mockSuppliers } from "@/data/mock";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Camera,
  FileText,
  Send,
  Plus,
  X,
} from "lucide-react";
import { toast } from "sonner";

export default function NewRFQ() {
  const [selectedSuppliers, setSelectedSuppliers] = useState<string[]>([]);

  const toggleSupplier = (id: string) => {
    setSelectedSuppliers((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("RFQ criada com sucesso!", {
      description: "Código: RFQ-2026-0043 · Fornecedores serão notificados.",
    });
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Nova RFQ</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Crie uma requisição de cotação para enviar aos fornecedores
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Product Info */}
        <div className="glass-card rounded-xl p-6 space-y-5">
          <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
            <FileText className="h-4 w-4 text-primary" />
            Dados do Produto
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Descrição do Produto *
              </Label>
              <Input
                placeholder="Nome técnico + nome comercial (ex: Conector IP67 12 Pinos)"
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Código VP para o Fornecedor *
              </Label>
              <Input
                placeholder="Ex: VP-CON-0042"
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Categoria
              </Label>
              <Select>
                <SelectTrigger className="bg-secondary/50 border-border/50">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="connectors">Conectores</SelectItem>
                  <SelectItem value="plastics">Plásticos</SelectItem>
                  <SelectItem value="metals">Metais</SelectItem>
                  <SelectItem value="electronics">Eletrônicos</SelectItem>
                  <SelectItem value="fasteners">Fixadores</SelectItem>
                  <SelectItem value="other">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">Cor *</Label>
              <Input
                placeholder="Pantone 293C, Hex #003DA5 ou descrição"
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Material / Composição *
              </Label>
              <Input
                placeholder="Ex: ABS Grau Alimentício, Aço Inox 304"
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Dimensões (C × L × P) *
              </Label>
              <Input
                placeholder="Ex: 120mm × 80mm × 45mm"
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Peso (Líquido / Bruto) *
              </Label>
              <Input
                placeholder="Ex: 250g / 320g"
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Certificações Necessárias
              </Label>
              <Input
                placeholder="ISO 9001, CE, FDA, RoHS..."
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Embalagem Desejada
              </Label>
              <Select>
                <SelectTrigger className="bg-secondary/50 border-border/50">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="individual">Individual</SelectItem>
                  <SelectItem value="master_carton">Master Carton</SelectItem>
                  <SelectItem value="pallet">Pallet</SelectItem>
                  <SelectItem value="custom">Personalizada</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Uso Previsto *
              </Label>
              <Textarea
                placeholder="Descreva para que serve o produto (contexto ajuda o fornecedor a entender melhor)"
                className="bg-secondary/50 border-border/50 min-h-[80px]"
              />
            </div>
          </div>
        </div>

        {/* Quantity & Deadline */}
        <div className="glass-card rounded-xl p-6 space-y-5">
          <h2 className="text-sm font-bold text-foreground">Quantidade & Prazo</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Quantidade *
              </Label>
              <Input
                type="number"
                placeholder="5000"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Moeda Base
              </Label>
              <Select defaultValue="USD">
                <SelectTrigger className="bg-secondary/50 border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD - Dólar</SelectItem>
                  <SelectItem value="EUR">EUR - Euro</SelectItem>
                  <SelectItem value="BRL">BRL - Real</SelectItem>
                  <SelectItem value="CNY">CNY - Yuan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-muted-foreground">
                Prazo Limite *
              </Label>
              <Input
                type="date"
                className="bg-secondary/50 border-border/50"
              />
            </div>
          </div>
        </div>

        {/* Files */}
        <div className="glass-card rounded-xl p-6 space-y-4">
          <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
            <Camera className="h-4 w-4 text-primary" />
            Fotos & Arquivos
          </h2>
          <p className="text-[10px] text-muted-foreground">
            Mínimo 3 fotos em ângulos diferentes + desenho técnico (PDF)
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="aspect-square rounded-lg border-2 border-dashed border-border/50 flex flex-col items-center justify-center gap-1 hover:border-primary/50 transition-colors cursor-pointer"
              >
                <Camera className="h-5 w-5 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground">Foto {i}</span>
              </div>
            ))}
            <div className="aspect-square rounded-lg border-2 border-dashed border-border/50 flex flex-col items-center justify-center gap-1 hover:border-primary/50 transition-colors cursor-pointer">
              <Plus className="h-5 w-5 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground">Mais</span>
            </div>
          </div>
          <div className="flex items-center gap-2 p-3 rounded-lg border border-dashed border-border/50 hover:border-primary/50 transition-colors cursor-pointer">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">
              Clique para anexar desenho técnico (PDF)
            </span>
          </div>
        </div>

        {/* Suppliers Selection */}
        <div className="glass-card rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
              <Send className="h-4 w-4 text-primary" />
              Selecionar Fornecedores
            </h2>
            <span className="text-[10px] text-muted-foreground font-medium">
              {selectedSuppliers.length} selecionado(s)
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {mockSuppliers.map((supplier) => (
              <label
                key={supplier.id}
                className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                  selectedSuppliers.includes(supplier.id)
                    ? "border-primary/50 bg-primary/5"
                    : "border-border/30 hover:border-border/60"
                }`}
              >
                <Checkbox
                  checked={selectedSuppliers.includes(supplier.id)}
                  onCheckedChange={() => toggleSupplier(supplier.id)}
                />
                <span className="text-lg">{supplier.flag}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground truncate">
                    {supplier.name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {supplier.country} · ⭐ {supplier.rating}
                  </p>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-end gap-3">
          <Button type="button" variant="outline" className="text-xs">
            Salvar Rascunho
          </Button>
          <Button
            type="submit"
            className="text-xs font-bold gap-2"
            disabled={selectedSuppliers.length === 0}
          >
            <Send className="h-3.5 w-3.5" />
            Enviar RFQ
          </Button>
        </div>
      </form>
    </div>
  );
}
