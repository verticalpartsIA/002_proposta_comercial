import {
  FileText,
  Users,
  TrendingUp,
  Clock,
  ArrowUpRight,
  Package,
} from "lucide-react";
import { mockRFQs, mockQuotations, mockSuppliers, statusLabels, statusColors } from "@/data/mock";
import { Link } from "react-router-dom";

const KPICard = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
}: {
  title: string;
  value: string | number;
  subtitle: string;
  icon: React.ElementType;
  trend?: string;
}) => (
  <div className="glass-card rounded-xl p-5 animate-fade-in">
    <div className="flex items-start justify-between mb-3">
      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      {trend && (
        <span className="text-[10px] font-semibold text-success flex items-center gap-0.5">
          <ArrowUpRight className="h-3 w-3" /> {trend}
        </span>
      )}
    </div>
    <p className="text-2xl font-bold text-foreground">{value}</p>
    <p className="text-xs text-muted-foreground mt-0.5">{title}</p>
    <p className="text-[10px] text-muted-foreground/60 mt-1">{subtitle}</p>
  </div>
);

export default function Dashboard() {
  const activeRFQs = mockRFQs.filter((r) => ["sent", "quoting", "ai_analysis"].includes(r.status));
  const totalQuotes = mockQuotations.length;
  const avgScore = Math.round(
    mockQuotations.filter((q) => q.score).reduce((acc, q) => acc + (q.score || 0), 0) /
      mockQuotations.filter((q) => q.score).length
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Visão geral das suas cotações e fornecedores
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="RFQs Ativas"
          value={activeRFQs.length}
          subtitle="Em andamento agora"
          icon={FileText}
          trend="+12%"
        />
        <KPICard
          title="Cotações Recebidas"
          value={totalQuotes}
          subtitle="Últimos 30 dias"
          icon={TrendingUp}
          trend="+8%"
        />
        <KPICard
          title="Fornecedores Ativos"
          value={mockSuppliers.length}
          subtitle="Em 4 países"
          icon={Users}
        />
        <KPICard
          title="Score Médio IA"
          value={`${avgScore}/100`}
          subtitle="Qualidade das cotações"
          icon={Package}
          trend="+5pts"
        />
      </div>

      {/* Recent RFQs */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-border/50">
          <div>
            <h2 className="text-sm font-bold text-foreground">RFQs Recentes</h2>
            <p className="text-[10px] text-muted-foreground mt-0.5">Últimas requisições de cotação</p>
          </div>
          <Link
            to="/quotations"
            className="text-xs font-semibold text-primary hover:text-primary/80 transition-colors"
          >
            Ver todas →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/30">
                <th className="text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">Código</th>
                <th className="text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">Produto</th>
                <th className="text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">Status</th>
                <th className="text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">Fornecedores</th>
                <th className="text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-5 py-3">Prazo</th>
              </tr>
            </thead>
            <tbody>
              {mockRFQs.map((rfq) => (
                <tr key={rfq.id} className="border-b border-border/20 hover:bg-secondary/30 transition-colors">
                  <td className="px-5 py-3">
                    <span className="text-xs font-bold text-primary">{rfq.code}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className="text-xs font-medium text-foreground">{rfq.title}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${statusColors[rfq.status]}`}>
                      {statusLabels[rfq.status]}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <span className="text-xs text-muted-foreground">
                      {rfq.quotesReceived}/{rfq.suppliersCount} cotações
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {rfq.deadline}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Quotations */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="p-5 border-b border-border/50">
          <h2 className="text-sm font-bold text-foreground">Últimas Cotações Recebidas</h2>
          <p className="text-[10px] text-muted-foreground mt-0.5">Respostas dos fornecedores</p>
        </div>
        <div className="divide-y divide-border/20">
          {mockQuotations.slice(0, 3).map((q) => (
            <div key={q.id} className="flex items-center justify-between p-5 hover:bg-secondary/30 transition-colors">
              <div className="flex items-center gap-3">
                <span className="text-lg">{q.supplierFlag}</span>
                <div>
                  <p className="text-xs font-semibold text-foreground">{q.supplierName}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {q.cotCode} · {q.rfqCode}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-sm font-bold text-foreground">
                    ${q.unitPrice.toFixed(2)}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{q.incoterm}</p>
                </div>
                {q.score && (
                  <div className={`text-xs font-bold px-2 py-1 rounded-full ${
                    q.score >= 90 ? "bg-success/20 text-success" :
                    q.score >= 80 ? "bg-primary/20 text-primary" :
                    "bg-warning/20 text-warning"
                  }`}>
                    {q.score}/100
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
